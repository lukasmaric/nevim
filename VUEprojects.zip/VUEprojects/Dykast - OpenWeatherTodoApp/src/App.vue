<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>
<template>
  <header>
    <nav class="navbar navbar-expand-md navbar-light">
      <div class="navbar-brand" href="/">Vladimír Dykast</div>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <RouterLink class="nav-link" to="/">Počasí</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" to="/ukolnicek">Úkolníček</RouterLink>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <div>
    <RouterView/>
  </div>
</template>