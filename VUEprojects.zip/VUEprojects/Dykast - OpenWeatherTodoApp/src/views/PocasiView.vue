<script setup>
  import Pocasi from '../components/Pocasi.vue'
</script>

<template>
  <div>
    <Pocasi/>
  </div>
</template>
