<script setup>
  import Ukolnicek from '../components/Ukolnicek.vue'
</script>

<template>
  <div>
    <Ukolnicek/>
  </div>
</template>