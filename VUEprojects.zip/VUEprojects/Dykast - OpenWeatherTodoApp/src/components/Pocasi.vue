<template>
    <div id="app" :class="typeof weather.main != 'undefined' && weather.main.temp > 16 ? 'warm + text-dark-black' : 'cold + text-light'">
      <main class="container text-center">
        <div class="display-2">Počasí</div>
        <div class="pb-4">
          <input type="text" class="form-control" placeholder="Hledat místo..." v-model="query" @keypress="fetchWeather"/>
        </div>
        <p class="d-inline-flex p-2 justify-content-center display-4 rounded p-2 font-weight-bold">
          <div v-if="typeof weather.main != 'undefined'">
          <div>
            <div>{{ weather.name }}, {{ weather.sys.country }}</div>
            <div>{{ dateBuilder() }}</div>
          </div>
  
          <div class="weather-box">
            <div>{{ Math.round(weather.main.temp) }}°C</div>
            <div class="container text-center justify-content-center">
              <div class="weather">{{ weather.weather[0].main }}</div>
                <div id="icon" :class="typeof weather.main != 'undefined' && weather.weather[0].main == 'Clear' ? 'clear' : ''"></div>
                <div id="icon" :class="typeof weather.main != 'undefined' && weather.weather[0].main == 'Mist' ? 'mist' : ''"></div>
                <div id="icon" :class="typeof weather.main != 'undefined' && weather.weather[0].main == 'Snow' ? 'snow' : ''"></div>
                <div id="icon" :class="typeof weather.main != 'undefined' && weather.weather[0].main == 'Clouds' ? 'cloud' : ''"></div>
                <div id="icon" :class="typeof weather.main != 'undefined' && weather.weather[0].main == 'Rain' ? 'rain' : ''"></div>
            </div>
          </div>
        </div>
        </p>
      </main>
    </div>
</template>
<script>
export default {
    name: 'Pocasi',
    props: {
        msg: String
    },
  data () {
    return {
      api_key: 'f6e49ce82a65a4662c4ee4cbffdb0c1b',
      url_base: 'https://api.openweathermap.org/data/2.5/',
      query: '',
      weather: {}
    }
  },
  methods: {
    fetchWeather (e) {
      if (e.key == "Enter") {
        fetch(`${this.url_base}weather?q=${this.query}&units=metric&APPID=${this.api_key}`)
          .then(res => {
            return res.json();
          }).then(this.setResults);
      }
    },
    setResults (results) {
      this.weather = results;
    },
    dateBuilder () {
      let d = new Date();
      let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
      let day = days[d.getDay()];
      let date = d.getDate();
      let month = months[d.getMonth()];
      let year = d.getFullYear();
      return `${day} ${date} ${month} ${year}`;
    }
  }
}
</script>
<style scoped>
  #app {
    background-size: cover;
    transition: 0.3s;
  }
  #app.warm {
    background-image: url("../assets/warm-bg.jpg");
    background-size: cover;
    transition: 0.3s;
  }
  #app.cold {
    background-image: url("../assets/cold-bg.jpg");
    background-size: cover;
    transition: 0.3s;
  }
  #icon { 
    transition: 0.3s;
    width: 50px;
    height: 50px;
    background-size: cover;
    position: absolute;
    top: 450px;
    left: 1060px;
  }
  #icon.clear{
    background-image: url("../assets/sun.png");
    transition: 0.3s;
  }
  #icon.snow {
    background-image: url("../assets/snow.png");
    transition: 0.3s;
  }
  #icon.mist {
    background-image: url("../assets/mist.png");
    transition: 0.3s;
  }
  #icon.cloud {
    background-image: url("../assets/cloud.png");
    transition: 0.3s;
  }
  #icon.rain {
    background-image: url("../assets/rain.png");
    transition: 0.3s;
  }
  p {
    transition: 0.3s;
  }
</style>
