<script setup>

import { ref, onMounted, computed, watch } from 'vue'
const todos = ref([])
const name = ref('')
const input_content = ref('')
const input_category = ref(null)
const todos_asc = computed(() => todos.value.sort((a,b) =>{
	return a.createdAt - b.createdAt
}))
watch(todos, (newVal) => {
	localStorage.setItem('todos', JSON.stringify(newVal))
}, {
	deep: true
})
const addTodo = () => {
	if (input_content.value.trim() === '') {
		return
	}
	todos.value.push({
		content: input_content.value,
		category: input_category.value,
		done: false,
		editable: false,
		createdAt: new Date().getTime()
	})
}
onMounted(() => {
	name.value = localStorage.getItem('name') || ''
	todos.value = JSON.parse(localStorage.getItem('todos')) || []

})
const removeTodo = (todo) => {
	todos.value = todos.value.filter((t) => t !== todo)
}
</script>
<template>
	<div id="zapisnik-image">
		<main class="container text-center">

<section class="create-todo">
	<div class="display-2">Úkolníček</div>

	<form @submit.prevent="addTodo">
		<div class="input-group mb-3">
		<input type="text" class="form-control" placeholder="Zadejte zápis" aria-label="Recipient's username" aria-describedby="basic-addon2" v-model="input_content">
		<div class="input-group-append">
			<button class="btn btn-success" type="submit">Přidat</button>
		</div>
	</div>
	</form>
</section>

<section class="todo-list">
	<h3 class="display-4">Vaše úkoly</h3>
	<div id="todo-list">
		<div v-for="todo in todos_asc" :class="` ${todo.done && 'done'}`">
                    <div class="input-group mb-2 w-50 d-inline-flex">
                        <div id="checkbox" class="d-flex">
                            <div class="d-flex input-group-text">
								<button type="button" class="btn" :class="{'btn-success': todo.done, 'btn-secondary': !todo.done}" @click="todo.done = !todo.done">✓</button>
                            </div>
                        </div>
						<div :class="(todo.done == true ? 'line form-control' : 'form-control text-center')" aria-label="Text input with checkbox">{{ todo.content }}</div>
                        <div class="input-group-append">
                            <button class="btn btn-danger" @click="removeTodo(todo)">X</button>
				</div>
			</div>
		</div>
	</div>
</section>
</main>
	</div>
</template>
<style scoped>
.line {
	text-decoration: line-through;
}
#zapisnik-image {
    background-size: cover;
    transition: 0.3s;
	background-image: url(../assets/zapisnik-image.jpg); 
  }
#checkbox {
	padding-right: 10px;
}
  </style>