<template lang="">
    <header>
        <img src="../assets/logo.png" alt="LOGO" height="50">
        <p>VueJS applikace</p>
        <nav>
            <router-link to="/">Home</router-link> |
            <router-link to="/about">About</router-link>
        </nav>
    </header>
</template>
<script>
export default {
    
}
</script>
<style scoped>
    header{
        display: flex;
        border-bottom: 1px black solid;
        padding: 0.5rem;
        align-items: center;
    }
    header p { 
        margin-left: 1rem;
        }
    nav {
        margin-left: auto;
    }
    nav>ul {
        list-style: none;
    }
    nav>ul>li {
        display: inline-flex;
        margin-left: 1rem;
    }

</style>