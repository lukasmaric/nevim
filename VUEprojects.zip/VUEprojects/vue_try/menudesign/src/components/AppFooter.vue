<template lang="">
    <div>
        Jmeno.Prijmeni &copy; {{thisyear}}
    </div>
</template>
<script>
export default {
    computed:{
        thisyear() {
            return new Date().getFullYear()
        }
    }
}
</script>
<style lang="">
    
</style>