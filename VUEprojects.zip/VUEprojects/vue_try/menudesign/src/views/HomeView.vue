<template>
  <div>
    <h1>{{title}}</h1>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'HomeView',
  data() {
    return {
      title:"Home Page"
    }
  }
}
</script>
