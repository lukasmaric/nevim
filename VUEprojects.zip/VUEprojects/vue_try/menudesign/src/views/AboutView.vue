<template>
  <div>
    <h1>{{title}}</h1>
  </div>
</template>

<script>
export default {
  name: 'AboutView',
  data() {
    return {
      title:"About Page"
    }
  },
}
</script>

<style lang="">
  
</style>