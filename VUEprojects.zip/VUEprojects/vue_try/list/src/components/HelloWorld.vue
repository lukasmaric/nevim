<template>
  <h1>{{nadpis}}</h1>

   <div>
    <input type="text" v-model="novinka" placeholder="INPUT">
    <button @click="addNovinka" :disabled="novinka.length < 1">Přidat</button>
  </div>

  <div v-if="novinka.length > 0">
    <h3>Novinka:</h3>
    <p>{{novinka}}</p>
  </div> 

  <ul>
    <li v-for="polozka in seznam" :key="polozka.id">
      {{polozka.id}}. {{polozka.nazev}} -
      <span v-if="polozka.dokoncen">
        SUPER
      </span>
      <span v-else>
      DOKONČIT
      </span>
    </li>
  </ul>
</template>

<script>
export default {
  data() {
    return{
      nadpis: "List zobrazení",
      novinka: "",
      seznam: [
        {id:1, nazev: "Nazev 1", dokoncen: false},
        {id:2, nazev: "Nazev 2", dokoncen: true},
        {id:3, nazev: "Nazev 3", dokoncen: true},
        {id:4, nazev: "Nazev 4", dokoncen: false},
      ]
    }
  },
  methods: {
    addNovinka() {
      this.seznam.push({
        id: this.seznam.length + 1,
        nazev: this.novinka,
        dokoncen: false
      });
      this.novinka = "";
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  /* display: inline-block; */
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
