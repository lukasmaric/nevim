<template>
  <div class="blog">
    <h1>Blog Page</h1>
    <router-link to="/blog/1">blog 1</router-link> |
    <router-link to="/blog/2">blog 2</router-link>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>