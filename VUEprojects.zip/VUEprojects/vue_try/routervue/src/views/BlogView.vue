<template>
  <div class="blog">
    <h1>Blog Page</h1>
    <h2>{{$route.params.id}}</h2>
    <router-link to="/blog">BACK</router-link>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>