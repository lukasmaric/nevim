<template>
  <!-- <img alt="Vue logo" src="./assets/logo.png"> -->
  <CompBook />
</template>

<script>
import CompBook from './components/CompBook.vue'

export default {
  name: 'App',
  components: {
    CompBook
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
