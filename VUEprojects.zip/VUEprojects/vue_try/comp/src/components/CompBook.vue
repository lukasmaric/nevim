<template>
    <div>
        <h1>{{title}}</h1>
        <h2>Autor: {{author.name}}</h2>
        <p>Vydal autor knižky: <span>{{publikaceKnih}}</span> </p>
        <p>Seznam knih:</p>
        <ul v-if="publikaceKnih">
            <li v-for="(data,index) in author.books" :key="index">
            {{data}}
            </li>
        </ul>
    </div>
    <hr>
    <p>{{now}}</p>
    <hr>
    <div>
        First: <input type="text" v-model="firstname"> <br>
        Second: <input type="text" v-model="secondname"> <br>
        <h2>Já jsem [{{firstname}}] [{{secondname}}]</h2>
        <h3>vypočítane: [{{getfullname}}]</h3>
    </div>
</template>

<script>
export default {
  name: 'CompBook',
  data() {
    return{
        title: "Autorovo info",
        firstname: "",
        secondname: "",
        author: {
            name: "John Bill",
            books: [
                "Story 1 - begin",
                "Story 2 - mid",
                "Story 3 - neverend"
            ]
        }
    }
  },
  computed:{
    publikaceKnih() {
        return this.author.books.length > 0 ? "Ano vydal":"Ne nepsal"
    },
    now(){
        var d = Date(Date.now());
        return d;
    },
    getfullname() {
        return this.firstname + " " + this.secondname
    }
  }
}
</script>

<style scoped>

</style>