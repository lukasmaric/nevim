<template>
  <div class="home">
    <h1>{{title}}</h1>

    <div class="row">
      <div class="card" 
      v-for="(data,index) in produkty" 
      :key="index">
          <img :src="data.image" alt="Obrazek">
          <h3>{{data.proTitle}}</h3>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'HomeView',
  data(){
    return{
      title:"Seznam",
      produkty: [
        { //OBJEKT 1
        proTitle:"Title Best",
        image: require('../assets/logo.png'),
        proId: 1
        },
        { //OBJEKT 2
        proTitle:"Title but Better",
        image: require('../assets/logo.png'),
        proId: 2
        }
      ]
    }

  }
}
</script>
