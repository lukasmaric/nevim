<template>
    <h1>{{title}}</h1>
  <div 
  v-for="(produkt, index) in produkty" 
  :key="index">
    <div v-if="pid == produkt.proId">
        <h1>{{produkt.proTitle}}</h1>
        <img :src="produkt.image" alt="Obrazek">
    </div>
  </div>
</template>

<script>
export default {
    name: 'DetailView',
    data(){
        return{
            pid: this.$route.params.pid,
            title: "detaily",
            produkty: [
                { //OBJEKT 1
                proTitle:"Title Best",
                image: require('../assets/logo.png'),
                proId: 1
                },
                { //OBJEKT 2
                proTitle:"Title but Better",
                image: require('../assets/logo.png'),
                proId: 2
                }
            ]
        }
    }
}
</script>

<style>

</style>