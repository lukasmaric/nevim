<template>
  <div class="hello">
    <ul v-for="todo in todoList" :key="todo.id">
      <li> {{todo.id}} - {{todo.title}}
        <div v-if="todo.completed" class="cg"> COMPLETE</div>
        <div v-else class="cr"> Dont Complete</div>
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'HelloWorld',
  data() {
    return {
      todoList: []
    }
  },
  mounted() {
    axios.get("https://jsonplaceholder.typicode.com/todos")
      .then(response => {
        this.todoList = [...response.data].slice(0,30)
      }).catch(err => {
        console.log(err)
      })
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.cr {
  color:red;
}
.cg {
  color:lightgreen;
}
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
