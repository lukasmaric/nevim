<template>
  <h1>{{title}}</h1>
  <img alt="Vue logo" src="./assets/logo.png">
  <div>
    <label for="">Uhodni číslo:</label><br>
    <input type="number" v-model.number="user_tip">    
  </div>
  <button @click="submit">Tipnout si</button>
  <hr>
  <h1>{{status}}</h1>
  <div v-if="vyhra">
    <h3> tipoval si {{pokus}}x  </h3>
    <button @click="start">Začít novou hru</button>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      title:"Minihra s čísly",
      odpoved:undefined,
      pokus:0,
      user_tip:0,
      status:"",
      vyhra:false
    }
  },
  methods: {
    getRandomNumber(min,max) {
      return Math.floor(Math.random()*(max -min +1))+min
    },
    start() {
      this.odpoved = this.getRandomNumber(0,10);
      console.log(this.odpoved);
      this.pokus = 0;
      this.vyhra = false;
      this.status = "";
    } ,
    submit(){
      this.pokus++;
      if (this.odpoved == this.user_tip){
        this.status = "WIN";
        this.vyhra = true;
      } else if (this.odpoved < this.user_tip){
        this.status = "Moc vysoko";
      } else {
        this.status = "Moc nízko";
      }
    }
  },
  mounted() {
    this.start();
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
