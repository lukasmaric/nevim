<template>
    <h1>{{title}}</h1>
<div class="row">
    <div class="col" v-for="(data,index) in produkty" :key="index">
        <div v-if="proId == data.productId">
            <h1>{{data.productTitle}}</h1>
            <img :src="data.image" :alt="data.productTitle">
        </div>
    </div>
</div>
</template>

<script>
export default {
    name:"detailsView",
    data(){
        return{
            proId: this.$route.params.Pid,
            title: "details",
            produkty: [
            {
              productId: 1,
              image: require("../assets/logo.png"),
              productTitle: "First item in produkty"
            },
            {
              productId: 2,
              image: require("../assets/logo.png"),
              productTitle: "Second item in produkty"
            }
            ]
        }
    }
}
</script>
<style>

</style>