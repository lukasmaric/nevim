<template>
  <h1>{{title}}</h1>
  <div class="row">
    <div class="col-4" v-for="(data,index) in produkty" :key="index">
      <img :src="data.image" :alt="data.productTitle">
      <h3 @click="goDetail(data.productId)"> {{data.productTitle}}</h3>
    </div>
  </div>
</template>

<script>

export default {
  name:"blogView",
  data(){
    return{
        title:"Blog", // název stránky
        produkty: [   //list produktu za pomocí [pole]-
            {
              productId: 1,
              image: require("../assets/logo.png"),
              productTitle: "First"
            },
            {
              productId: 2,
              image: require("../assets/logo.png"),
              productTitle: "Second"
            }

        ]
      }
    },
    methods: {
      goDetail(proId){
        let prodId = proId
        this.$router.push({name:"details",params:{Pid:prodId}})
      }
    }
}
</script>

<style>

</style>