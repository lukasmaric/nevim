<template>
  <ul>
    <li v-for="(todolist, index) in TodoList" :key="index">
        <span>{{todolist.name}}</span>
        <span class="delete" @click="Delete(todolist.id)">X</span>
    </li>
  </ul>
</template>

<script>
export default {
    props: {
        TodoList: Array,
        Delete: Function
    },
}
</script>

<style scoped>
ul{
    list-style: none;
    flex-direction: column;
    margin: auto;
    width: 50%;
}
li{
    display: flex;
    margin:5px 0;
    justify-content: space-between;
    align-content: center;
}
.delete{
    background-color: red;
    color: white;
    padding: 0 10px;
    line-height: 1;
    border-radius: 5px;
}





</style>