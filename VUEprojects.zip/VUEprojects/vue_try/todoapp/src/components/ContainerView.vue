<template>
  <div class="container">
    <input type="text" v-model="msg">
    <button @click="Create">Add</button>
  </div>
  <TodoListView :TodoList="TodoList" :Delete="Delete" />
</template>

<script>
import { ref } from "@vue/runtime-core"
import TodoListView from "./TodoListView";
export default {
components:{
        TodoListView,
    },
setup(){
    let welcomedata = [ {id:1, name:"Vue Todo List"},];
    return {
        TodoList: ref(welcomedata)
        };
    },
data(){
    return{
        id:4
    }
},
methods: {
    Create() {
            this.id += 1;
            const next = {id:this.id, name:this.msg};
            this.TodoList.push(next);
        },
    Delete(idx) {
        this.TodoList = this.TodoList.filter((r)=> r.id !== idx);
        }
    }
}
</script>

<style>

</style>