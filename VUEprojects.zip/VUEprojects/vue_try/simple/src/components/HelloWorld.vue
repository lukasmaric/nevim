<template>
  <div>
    <h1>{{title}}</h1>
    <button 
    @click.left="num1++" 
    @click.right="num1--" 
    @click.middle="megaupgrade()"
    >CLICK</button>
    <h2>Počet bodu je {{num1}}</h2>
    <div v-if="(num1 >10)">
      <button @click.once="megaupgrade()">MEGA UPGRADE</button>
    </div>

    <!-- V-FOR výběr -->

    <h2>Oblíbený programovací jazyk: {{prolang}}</h2>
    <!-- For v1 -->
    <button v-for="(data,index) in listlang" :key="index" 
    @click="prolang = data">
      {{data}}
    </button>
    <!-- For v2 -->
    <div v-for="(data,index) in listlang" :key="index">
      <button @click="prolang = data">{{data}}</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data(){
    return{
      title: "Simple",
      num1 : 0,
      prolang:"",
      listlang: ["PHP", "JavaScript", "C#", "Java", "C++"]
    }
  },
  methods:{
    megaupgrade(){
      this.num1 += 1000;
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
