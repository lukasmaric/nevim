<template>
  <div class="form-container">
    <h1>Výpůjčka</h1>
    <form @submit.prevent="saveData">
      <label>
        Jméno:
        <input type="text" v-model="name" required />
      </label>
      <label>
        Příjmení:
        <input type="text" v-model="surname" required />
      </label>
      <label>
        Číslo čtenáře:
        <input type="number" v-model="readerNumber" required />
      </label>
      <label>
        Název knihy:
        <input type="text" v-model="bookTitle" required />
      </label>
      <label>
        ISBN:
        <input type="text" v-model="isbn" required />
      </label>
      <label>
        Datum:
        <input type="date" v-model="date" required />
      </label>
      <button type="submit">Uložit</button>
    </form>
    <div v-if="saved">
      <p>Uloženo:</p>
      <p>{{ name }} {{ surname }}</p>
      <p>Číslo čtenáře: {{ readerNumber }}</p>
      <p>Název knihy: {{ bookTitle }}</p>
      <p>ISBN: {{ isbn }}</p>
      <p>Datum: {{ date }}</p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      name: "",
      surname: "",
      readerNumber: "",
      bookTitle: "",
      isbn: "",
      date: "",
      saved: false,
    };
  },
  methods: {
    saveData() {
      this.saved = true;
    },
  },
};
</script>

<style>
body{
  background-color: lightgray;
}
.form-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 2rem;
}
label {
  display: block;
  margin-bottom: 10px;
  font-family: 'Times New Roman', Times, serif;
}
input[type="text"],
input[type="number"],
input[type="date"] {
  margin-bottom: 1rem;
  padding: 0.5rem;
  border-radius: 5px;
  border: none;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
}
button[type="submit"] {
  background-color: green;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 0.5rem 1rem;
  cursor: pointer;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
}
button[type="submit"]:hover {
  background-color: #0062cc;
}
p {
  margin: 10px;
}
h1 {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 40px;
}
</style>
