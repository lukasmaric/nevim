# JavaScript-vsehochut

3.I WTL - Zde jsou veškerý JavaScript projekty které jsme dělali, nebo budeme dělat. Popis jeste bude upraven postupne 

### seznam souborů
- *alert.html* - zkouška alertu
- *eval.html* - vyzkoušení funkce eval (WIP)
- *hodkostkou.html* - jednoducha webová stránka s funkcí hodkostkou() kterou bere z **pocitadlo.js**
- *hra.html* + *hra.js* - malá jednoduchá minihra inspirovaná dračím doupětem
- *mapa.html* - pracovní název pro vygenerovaní mapy pro *hra.js*
- *pc.html* - jednoduché přidávání a odebíraní hodnoty s css a "knihovnou pocitadlo.js"
- *pocitadlo.html* - jednoduché přidávání a odebíraní hodnoty bez css
- *pribeh.html* - jednoducha *Text Based Adventure* v JS
- *promenne.html* - seznámení s proměnými
- *quiz.html* + *quit.js* - složitejší hra na otazky s využiti prompt, confirm, alert
- *seznamy.html* + *seznamy_v2.html* - změna css za pomocí html tabulky a JS
- *todo.html* - todo app s vymazáním ale nemá vyřešené ukládání do LocalStorage
- *uvod.html*
- *zmenapisma.html*
- *zvetsovadlo.html*
- **style.css** - globalní css soubor pro všechno ☺
### zdroje
- js_logo.png - https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Unofficial_JavaScript_logo_2.svg/480px-Unofficial_JavaScript_logo_2.svg.png