function vynulovat() {
    document.getElementById("cislo").innerText = 0;
}

function pridat() {
    let x = document.getElementById("cislo").innerText;
    x = parseInt(x)+1; 
    document.getElementById("cislo").innerText = x;
}

function odebrat() {
    var x = document.getElementById("cislo").innerText;
    x = parseInt(x)-1;
    document.getElementById("cislo").innerHTML = x;    
}

function createAlert(textAlertu) {
    alert(textAlertu)
}

function hodkostkou(stena) {
    //alert(stena);
    let x = 1 + Math.floor(Math.random() * stena);
    console.log(x);

    var y = document.getElementById("vysledek");
    if (y != null){
        document.getElementById("vysledek").innerText = "Při hodu " + stena + " stěnnou kostkou si hodil " + x;
    }
}