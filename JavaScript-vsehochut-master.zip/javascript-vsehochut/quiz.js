let points = 0;

let trueq = ["Je obloha modra?", 
"Mikrofon je na záznam zvuku?", 
"Reproduktory vydavaji zvuk?", 
"Je monitor obrazové zařizení?"];
let falseq =["V neděli se chodi do školy?", 
"Je tiskárna vstupní obrazové zařízení?", 
"Je papír digitalní materiál?"];
let textq =["Která periférie nám umožňuje hýbat s kurzorem?(vše malý a bez háčků a čárek)|mys",
"Která komponenta je nyní nedostupná díky kryptoměnám?(celý název)|graficka karta",
"Jakou zkratku má Procesor?(vše malý)|cpu"];
let moreq = ["Základní komponenty PC?|cpu, gpu, ram, zdroj, zakladni deska, disk",
"Jaké dny jsou ve víkendu?|sobota, nedele",
"Pracovní dny jsou jaké?|pondeli, utery, streda,ctvrtek,patek",
"Jaké jsou letní měsíce?|cerven, cervenec, srpen"]


function polozitotazku1(zadani, odpoved = true) {
    // console.log(confirm(zadani));
    var hlas = confirm(zadani);
    if(odpoved == true){
        if(hlas){
            console.log("pridan bod");
            points++; // points = points + 1
        } else {
            console.log("spatna odpoved");
        }
    } else {
        if(!hlas){
            console.log("pridan bod");
            points++;
        } else {
            console.log("spatna odpoved");
        }
    }
}

function polozitotazku2(zadani, odpoved) {
    var hlas = prompt(zadani);
    console.log(hlas);
    if (hlas == odpoved) {
        console.log("pridan bod");
        points++;
    } else {
        console.log("spatna odpoved");
    }
}
//Otazka -> Časté periefie na stole? (oddělit čárkou)
//odpovedi -> mys, klavesnice, monitor,
function polozitotazku3(otazka,odpovedi) {
    var hlas = prompt(otazka); 
    
    let notformat = odpovedi.replaceAll(" ","");
    hlas = hlas.replaceAll(" ","");
    
    var formated = notformat.split(",")
    hlas = hlas.split(",");

    console.log(hlas);
    console.log(formated);

    for (let i = 0; i < formated.length; i++) {
        for (let n = 0; n < hlas.length; n++) {
            if (formated[i] == hlas[n]){
                points++;
                console.log("pridan bod")
            } else{
                console.log("spatna odpoved")
            } 
        }
        
    }

}

function gentrueq(index) {
    var vyber = Math.floor(Math.random() * trueq.length);
    polozitotazku1(index+ " - " +trueq[vyber]);
}

function genfalseq(index) {
    var vyber = Math.floor(Math.random() * falseq.length);
    polozitotazku1(index+ " - " +falseq[vyber],false);
}

function genfullq(index) {
    var vyber = Math.floor(Math.random() * textq.length);
    let notformat = textq[vyber];
    const formated = notformat.split("|");
    polozitotazku2(index+" - "+formated[0],formated[1]);
}

function genmoreq(index) {
    var vyber = Math.floor(Math.random() * moreq.length);
    let notformat = moreq[vyber];
    const formated = notformat.split("|");
    polozitotazku3(index+" - "+formated[0],formated[1]);
}




function game(obtiznost = 3) {
    points = 0;    
    for (let i = 0; i < obtiznost; i++) {
        let index = i+1;
        var nahodnost = Math.floor(Math.random()*4);
        if(nahodnost == 0){
            gentrueq(index);
        } else if (nahodnost == 1){
            genfalseq(index);
        } else if (nahodnost == 2){
            genfullq(index);
        } else{
            genmoreq(index);
        }
    }

    alert("získal jsi " + points +" z "+obtiznost+" otázek");
}

