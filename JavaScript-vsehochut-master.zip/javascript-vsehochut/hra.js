//nastavení proměných
var enemyName = ['Duch', 'Vlk', 'Učitel', "Lebka", "Kostlivec"];
var enemyHp = hodkostkou(50);
var enemyDamage = hodkostkou(10);

var heroHp = 40;
var heroDamage = 6;
let heroDefend = false;


function init() {
    nameChoise = Math.floor(Math.random() * enemyName.length)
    document.getElementById("enemyName").innerText = enemyName[nameChoise];
    document.getElementById("enemyHp").innerText = enemyHp;
    document.getElementById("enemyDamage").innerText = enemyDamage;
    document.getElementById("heroHp").innerText = heroHp;
}

//FUNKCE
function heal() {
    heroHp = parseInt(heroHp) + parseInt(hodkostkou(10));
    battlelog("Výlečil ses <br>");
    document.getElementById("heroHp").innerText = heroHp;

    enemyAttack();
    gameover();
}

function attack() {
    enemyHp = parseInt(enemyHp) - parseInt(heroDamage);
    battlelog("Zautočil jsi<br>");
    document.getElementById("enemyHp").innerText = enemyHp;

    enemyAttack();
    gameover();
}

function defend() {
    heroDefend = true;
    battlelog("Použil jsi obranu <br>");
    gameover();
}

function luck() {
    let luck = hodkostkou(10)
    if (luck < 5){
        heroHp = 0;
    } else {
        enemyHp = 0;
    }
    gameover()
}

function enemyAttack() {
    if (!heroDefend) {
        battlelog("nepřítel zaútočil <br>");
        heroHp = parseInt(heroHp) - parseInt(enemyDamage);
        document.getElementById("heroHp").innerText = heroHp;
        heroDefend = false;
    } else {
        battlelog("vykryl jsi protiútok <br>");
        heroDefend = false;
    }

    gameover()
}

//Globalní funkce
function hodkostkou(stena) {
    //alert(stena);
    let x = 1 + Math.floor(Math.random() * stena);
    console.log("x:"+x);
    return x;
}

function gameover() {
    console.log("zjistuji stav -Enemy"+enemyHp + ",hero"+heroHp);
    console.log()
    if(enemyHp <= 0){
        document.getElementById("game").innerHTML = "<h1> Vyhrál jsi </h1>"
    } else if (heroHp <= 0) {
        document.getElementById("game").innerHTML = "<h1> Prohrál jsi </h1>"

    }
}

function battlelog(text2log) {
    document.getElementById("battlelog").innerHTML += text2log;
}