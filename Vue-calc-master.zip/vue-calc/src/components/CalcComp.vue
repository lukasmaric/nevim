<template>
    <div class="calculator">
        <div class="display">{{current || '0'}}</div>
        <div class="btn operator" @click="clear">C</div>
        <div class="btn operator">+/-</div>
        <div class="btn operator" @click="procent">%</div>
        <div class="btn operator" @click="divide">/</div>
        <div class="btn" @click="append(7)">7</div>
        <div class="btn" @click="append(8)">8</div>
        <div class="btn" @click="append(9)">9</div>
        <div class="btn operator" @click="times">*</div>
        <div class="btn" @click="append(4)">4</div>
        <div class="btn" @click="append(5)">5</div>
        <div class="btn" @click="append(6)">6</div>
        <div class="btn operator" @click="minus">-</div>
        <div class="btn" @click="append(1)">1</div>
        <div class="btn" @click="append(2)">2</div>
        <div class="btn" @click="append(3)">3</div>
        <div class="btn operator" @click="add">+</div>
        <div class="btn nula" @click="append(0)">0</div>
        <div class="btn ">.</div>
        <div class="btn operator" @click="equal">=</div>
    </div>
</template>

<script>
export default{
    data(){
        return{
            current: '',
            previous: null,
            operator: null,
            operatorClicked: false
        }
    },
    methods:{
        // vedlejší metody
        //vyčičtění
        clear() {
            this.current = "";
        },
        //přídaní čísla
       append(number) {
        if (this.operatorClicked)
        {
            this.current="";
            this.operatorClicked= false;
        }
        this.current= `${this.current}${number}`;
       },
       //ošetření vstupu
       setPrevious(){
        this.previous = this.current;
        this.operatorClicked = true;
       },
       //Jednotlive operace
       //sčítání
       add() {
        this.operator = (a,b) => a + b;
        this.setPrevious();
       },
       //Odčítání
       minus(){
        this.operator = (a,b) => a - b;
        this.setPrevious();
       },
       //Dělení
       divide(){
        this.operator = (a,b) => a / b;
        this.setPrevious();
       },
       //Násobení
       times() {
        this.operator = (a,b) => a * b;
        this.setPrevious();
       },
       //Procento
       procent() {
        this.current = this.current / 100;
       },
       //VÝSLEDEK
       equal() {
        this.current = this.operator(parseFloat(this.previous),parseFloat(this.current));
       this.previous = null;
    }
    }
}
</script>

<style scoped>
.calculator {
    width: 400px;
    margin: 0 auto;
    font-size:40px;
    display: grid;
    grid-template-columns: repeat(4,1fr);
    grid-auto-rows: minmax(50px,auto); 
}

.display{
    grid-column: 1/5;
    background-color: lightblue;
}

.btn{
background-color: lightgray;
border: 1px solid gray;
}

.nula {
    grid-column: 1/3;
}

.operator {
    background-color: orange;
    color: whitesmoke;
}

</style>