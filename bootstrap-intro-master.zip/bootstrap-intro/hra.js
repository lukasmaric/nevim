//nastavení proměných
var enemyName = ['Duch', 'Vlk', 'Učitel', "Lebka", "Kostlivec"];
var enemyHp = hodkostkou(50);
var enemyDamage = hodkostkou(10);

var heroHp = 40;
var heroDamage = 6;
let heroDefend = false;


function init() {
    nameChoise = Math.floor(Math.random() * enemyName.length)
    document.getElementById("enemyName").innerText = enemyName[nameChoise];
    document.getElementById("enemyHp").innerText = enemyHp;
    document.getElementById("enemyDamage").innerText = enemyDamage;
    document.getElementById("heroHp").innerText = heroHp;
}

//FUNKCE
function heal() {
    heroHp = parseInt(heroHp) + parseInt(hodkostkou(10));
    battlelog(`<div class="alert alert-success">
        	    Vyléčil ses </div>`);
    document.getElementById("heroHp").innerText = heroHp;

    enemyAttack();
    gameover();
}

function attack() {
    enemyHp = parseInt(enemyHp) - parseInt(heroDamage);
    battlelog('<div class="alert alert-danger">Zaútočil jsi </div>');
    document.getElementById("enemyHp").innerText = enemyHp;

    enemyAttack();
    gameover();
}

function defend() {
    heroDefend = true;
    battlelog('<div class="alert alert-warning">Použil jsi obranu! </div>');
    gameover();
}

function luck() {
    let luck = hodkostkou(10)
    if (luck < 5){
        heroHp = 0;
    } else {
        enemyHp = 0;
    }
    gameover()
}

function enemyAttack() {
    if (!heroDefend) {
        battlelog('<div class="alert alert-secondary">Nepřítel zaútočil </div>');
        heroHp = parseInt(heroHp) - parseInt(enemyDamage);
        document.getElementById("heroHp").innerText = heroHp;
        heroDefend = false;
    } else {
        battlelog('<div class="alert alert-primary">Vykril jsi útok </div>');
        heroDefend = false;
    }

    gameover()
}

//Globalní funkce
function hodkostkou(stena) {
    //alert(stena);
    let x = 1 + Math.floor(Math.random() * stena);
    console.log("x:"+x);
    return x;
}

function gameover() {
    console.log("zjistuji stav -Enemy"+enemyHp + ",hero"+heroHp);
    console.log()
    if(enemyHp <= 0){
        // zpetná uvozovka -> L.ALT + ý (7 nad písmeny) = ``
        document.getElementById("game").innerHTML = `
        <div class="container">
            <div class="d-flex align-items-center justify-content-center" 
            style="padding-top:25%">
                <h1 class="display-1 ">☺Vyhrál jsi☺</h1>
            </div>
        </div>
        `
    } else if (heroHp <= 0) {
        document.getElementById("game").innerHTML = `
        <div class="container">
            <div class="d-flex align-items-center justify-content-center" style="padding-top:25%">
                <h1 class="display-1 ">►Prorál jsi◄</h1>
            </div>
        </div>
        `

    }
}

function battlelog(text2log) {
    document.getElementById("battlelog").innerHTML += text2log;
}