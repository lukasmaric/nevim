﻿# bootstrap-intro

primárně pro 3.IM - Uvod do Bootstrapu a příprava na používaní boostrapu

## Bootstrap
Používáme [CSS Framework bootstrap v5.1.3](https://getbootstrap.com/docs/5.1/getting-started/download/)

Stáhneme si **Compiled CSS and JS** a otevřeme stažený soubor *boostrap-verze-dist.zip*(7zip, winRar, winZip, atd.)

uvnitř se nachází složka která obsahuje složky *css* a *js* -> tyto složky vložíme do složky s projektem

poté do našeho používaného HTML souboru do hlavičky vložíme *link* na css/bootstrap.css
```html
<link rel="stylesheet" href="css/bootstrap.css">
```
Nad nakonec `</body>` budeme chtít impotovat *bootstrap.bundle.js*
```html
    <script src="js/bootstrap.bundle.js"></script>
</body>
</html>
```

## seznam souborů
- TEMPLATE.HTML - základní bootstrap template s kterým pracujeme
- hra.html + hra.js - jednoducha minihra s Javascript
- kalukalcka.html - kalkulačka s bootstrap talčítky a jednoduchý JS
- objekty.html - grid systém, group list a formulář s  input group
- obrazky.html - zpracování obrázku, karty, slideshow, MODAL
- onepage.html - jednoducha *onepage* stránka s "jumbotron", text v grid systemu, list textu a jednoduchy kontaktní formulář
- responsive.html - Grid systém a flex
- tabulky.html - jednoduchá tabulka
- typografie.html - zpracování textu i s ukázkama kódů