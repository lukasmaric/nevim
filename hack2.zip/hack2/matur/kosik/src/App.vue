<template>
    <div>
        <h1>Knihkupectví</h1>
        <div class="row">
            <div class="col">
                <h2>Knihy</h2>
                <div v-for="(kniha, i) in knihy" :key="i">
                    {{ kniha.nazev }}
                    <img :src="kniha.obrazek" style="width: 30px" alt="">
                    <button
                        v-on:click="typKniha(kniha, typ)"
                        class="btn"
                        v-bind:class="{
                            'btn-success': kniha.typ_volba == typ.nazev,
                            'btn-outline-secondary':
                                kniha.typ_volba != typ.nazev,
                        }"
                        v-for="(typ, i) in kniha.typy"
                        :key="i"
                    >
                        <i class="fas" v-bind:class="typ.ikona"></i>
                        {{ typ.nazev }}
                    </button>
                    <p>
                        {{ kniha.format_volba }}
                    </p>
                    <p>
                        <button v-on:click="kosik.push(kniha)">do košíku</button>
                    </p>
                </div>
            </div>
            <div class="col">
                <h2>Košík</h2>
                <div v-for="(kniha, i) in kosik" :key="i">
                    {{ kniha.nazev }} <br>
                    {{ kniha.format_volba }} <br>
                    <input type="number" min="1" v-model="kniha.pocet">
                    {{ kniha.pocet * kniha.cena }} Kč
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import data from "./assets/knihy.json";

export default {
    name: "App",
    data: function () {
        return {
            knihy: data,
            kosik: [],
        };
    },
    methods: {
        typKniha: function(kniha, typ) {
            kniha.typ_volba = typ.nazev
            kniha.format_volba = typ.formaty
        },
    },
};
</script>

<style>
</style>
