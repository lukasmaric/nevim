import time

def get_integer_value(n=1):
  user_value = input(f"Napiš {str(n)}. číslo: ")
  try:
    return int(user_value)
  except ValueError:
    print(f"{user_value} není číslo. Zkus to znova.")
    return get_integer_value(str(n))

def scitani(c1,c2):
    vysledek=c1+c2
    print(str(c1) + " + " + str(c2) + " = " + str(vysledek))
    return(vysledek)    

def odecitani(c1,c2):
    vysledek = c1-c2
    print(str(c1) + "  -" + str(c2) + " = " + str(vysledek))
    return(vysledek) 

def nasobeni(c1,c2):
    vysledek = c1*c2
    print(str(c1) + " * " + str(c2) + " = " + str(vysledek))
    return(vysledek) 

def deleni(c1,c2):
    if c2 != 0:
        vysledek = c1/c2
        print(str(c1) + " / " + str(c2) + " = " + str(vysledek))
    else:
        print("Druhé číslo nesmí být nula")
    return(vysledek)    

print("Vítej v kalkulačce")

while True:
    print("------------------")
    print("Menu:")
    print("a) sčítání")
    print("b) odčítání")
    print("c) násobení")
    print("d) dělení")
    print("all) vse dohromady")
    print("e) EXIT")
    vyber = input("napiš písmeno:")

    if vyber=="e":
        exit(1)

    if vyber == "a" or vyber == "b" or vyber == "c" or vyber == "d" or vyber=="all":
        cislo1 = get_integer_value()
        cislo2 = get_integer_value(2)
        vysledek = 0

        if vyber=="a":
            print("vybral sis sčítání")
            scitani(cislo1,cislo2)
            
        elif vyber=="b":
            print("vybral sis odčítání")
            odecitani(cislo1,cislo2)
        elif vyber=="c":
            print("vybral sis násobení")
            nasobeni(cislo1,cislo2)
        elif vyber=="d":
            print("vybral sis dělení")
            deleni(cislo1,cislo2)
        elif vyber=="all":
            scitani(cislo1,cislo2)
            odecitani(cislo1,cislo2)
            nasobeni(cislo1,cislo2)
            deleni(cislo1,cislo2)

        time.sleep(3)
    