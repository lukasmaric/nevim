import random

for i in range(10):
    if(i!=9):
        print(random.randint(1,20),end=",")
    else:
        print(random.randint(1,20))