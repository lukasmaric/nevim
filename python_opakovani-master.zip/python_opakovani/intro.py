import random

print ("hod kostkou")
klavesa = True
while klavesa:
    kostka = int(input("Kolik hodnot bude mit kostka: "))
    randomNum = random.randint(0,kostka)
    print(randomNum)
    konec = input("Pro pokracovani stiskni enter. ")
    if (konec == "exit"):
        klavesa = False
print("Neplecha ukončena")