print("Kalkulacka")
klavesa = True
while klavesa:
    #základní volbu
    print("zadej cislo operace")
    print("1. scitani")
    print("2. odcitani")
    print("3. nasobeni")
    print("4. deleni")
    volba = input("jaka je tvoje volba: ")

    #pridat cisla na konkretní operace
    cislo1 = int(input("Cislo 1: "))
    cislo2 = int(input("Cislo 2: "))
    vysledek = 0 

    #provest operaci

    if (volba == "1"):
        vysledek = cislo1 + cislo2
        print("příklad " + str(cislo1) + "+" + str(cislo2) + "=" + str(vysledek))
    if (volba == "2"):
        vysledek = cislo1 - cislo2
        print("příklad " + str(cislo1) + "-" + str(cislo2) + "=" + str(vysledek))

    if (volba == "3"):
        vysledek = cislo1 * cislo2
        print("příklad " + str(cislo1) + "*" + str(cislo2) + "=" + str(vysledek))

    if (volba == "4"):
        vysledek = cislo1 / cislo2
        print("příklad " + str(cislo1) + "/" + str(cislo2) + "=" + str(vysledek))
    
    #ukonceni loopu    
    konec = input("Pro pokracovani stiskni enter. ")      
    if (konec == "exit"):
        klavesa = False

