# python_opakovani

Tento repozitář  obsahuje základní python scripty na zopakování *proměných, cyklů a podmínek*

A ještě to abych se já naučil nahrávat na tento gitea server ☺